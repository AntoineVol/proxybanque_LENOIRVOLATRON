package business;

import domain.ChequeBook;
/**
 * Couche service des chequiers
 * @author Fabien LENOIR & Antoine VOLATRON
 *
 */
public class ChequeBookBusiness extends CrudBusiness<ChequeBook>{

}
