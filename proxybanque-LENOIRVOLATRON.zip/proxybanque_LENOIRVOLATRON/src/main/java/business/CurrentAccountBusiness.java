package business;

import domain.CurrentAccount;

/**
 * Couche service des comptes courants
 * @author Fabien LENOIR & Antoine VOLATRON
 *
 */
public class CurrentAccountBusiness extends CrudBusiness<CurrentAccount>{
	
	
	


}
