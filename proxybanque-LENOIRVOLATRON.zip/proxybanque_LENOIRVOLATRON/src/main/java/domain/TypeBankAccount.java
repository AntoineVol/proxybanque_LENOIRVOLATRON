package domain;
/**
 * La classe TypeBankAccount permet d'identifier avec un énum le compte courant ou épargne.
 * @author Fabien LENOIR & Antoine VOLATRON
 *
 */
public enum TypeBankAccount {
	SAVING_ACCOUNT, CURRENT_ACCOUNT;
	

}
