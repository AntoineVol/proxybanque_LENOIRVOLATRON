package domain;
/**
 * La classe TypeBankCard permet d'identifier avec un énum les cartes bancaires Visa Premier ou Electron.
 * @author Fabien LENOIR & Antoine VOLATRON
 *
 */
public enum TypeBankCard {
	VISA_PREMIER, VISA_ELECTRON;
}
