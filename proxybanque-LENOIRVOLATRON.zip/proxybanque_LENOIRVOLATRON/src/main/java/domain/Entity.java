package domain;

/**
 *
 * @author Fabien LENOIR & Antoine VOLATRON
 *   
 */
public interface Entity {
	Integer getId();
	void setId(Integer id);

}
